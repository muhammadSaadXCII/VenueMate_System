import 'package:flutter/material.dart';
import '../Models/booking_model.dart';
import '../Services/booking_service.dart';
import 'HomePageVenueScreen.dart';
import 'ViewReciept.dart';

class CongratulationsScreen extends StatelessWidget {
  final String bookingId;

  const CongratulationsScreen({super.key, required this.bookingId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: StreamBuilder<BookingModel?>(
        stream: BookingService.streamBookingById(bookingId),
        builder: (context, snapshot) {
          final booking = snapshot.data;

          return SafeArea(
            child: Column(
              children: [
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.symmetric(horizontal: 24.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const SizedBox(height: 60),

                        // ── Animated success graphic ───────────────────────
                        _AnimatedSuccessGraphic(),

                        const SizedBox(height: 40),

                        const Text(
                          'Congratulations!',
                          style: TextStyle(
                            fontSize: 32,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                            letterSpacing: -0.5,
                          ),
                        ),

                        const SizedBox(height: 12),

                        Text(
                          booking != null
                              ? 'Your booking request has been submitted.\nThe hall admin will verify your receipt shortly.'
                              : 'Your booking request has been submitted successfully.',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            fontSize: 15,
                            color: Colors.grey[600],
                            height: 1.5,
                          ),
                        ),

                        const SizedBox(height: 16),

                        // Pending notice
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFFFBEB),
                            borderRadius: BorderRadius.circular(8),
                            border: Border.all(color: const Color(0xFFFDE68A)),
                          ),
                          child: Row(
                            children: [
                              const Icon(
                                Icons.access_time,
                                color: Color(0xFFD97706),
                                size: 18,
                              ),
                              const SizedBox(width: 8),
                              const Expanded(
                                child: Text(
                                  'Status: Pending — Hall admin will verify your receipt and confirm your booking.',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: Color(0xFF92400E),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 32),

                        // ── Booking details card ───────────────────────────
                        Container(
                          padding: const EdgeInsets.all(20),
                          decoration: BoxDecoration(
                            color: const Color(0xFFFDFDFD),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: Colors.grey.withOpacity(0.12),
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.grey.withOpacity(0.08),
                                blurRadius: 15,
                                offset: const Offset(0, 8),
                              ),
                            ],
                          ),
                          child:
                              booking != null
                                  ? Column(
                                    children: [
                                      _detailRow(
                                        'Booking ID',
                                        booking.invoiceId,
                                      ),
                                      const Divider(height: 24),
                                      _detailRow('Hall', booking.hallName),
                                      const Divider(height: 24),
                                      _detailRow('Event', booking.eventName),
                                      const Divider(height: 24),
                                      _detailRow(
                                        'Date',
                                        booking.eventDateLabel,
                                      ),
                                      const Divider(height: 24),
                                      _detailRow(
                                        'Grand Total',
                                        'Rs. ${booking.grandTotal.toStringAsFixed(0)}',
                                        isBold: true,
                                      ),
                                      const Divider(height: 24),
                                      _detailRow(
                                        'Advance Paid (25%)',
                                        'Rs. ${booking.advancePayment.toStringAsFixed(0)}',
                                        valueColor: const Color(0xFF16A34A),
                                      ),
                                    ],
                                  )
                                  : const Padding(
                                    padding: EdgeInsets.symmetric(vertical: 20),
                                    child: CircularProgressIndicator(
                                      color: Color(0xFFF97316),
                                    ),
                                  ),
                        ),
                      ],
                    ),
                  ),
                ),

                // ── Bottom action buttons ────────────────────────────────
                Container(
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    children: [
                      SizedBox(
                        width: double.infinity,
                        height: 56,
                        child: ElevatedButton(
                          onPressed: () {
                            Navigator.pushAndRemoveUntil(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const HomeScreen(),
                              ),
                              (route) => false,
                            );
                          },
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFFF47C20),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16),
                            ),
                            elevation: 0,
                          ),
                          child: const Text(
                            'Back to Home',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder:
                                  (_) =>
                                      ViewReceiptScreen(bookingId: bookingId),
                            ),
                          );
                        },
                        style: TextButton.styleFrom(
                          foregroundColor: Colors.grey[700],
                        ),
                        child: const Text('View E-Receipt'),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _detailRow(
    String label,
    String value, {
    bool isBold = false,
    Color? valueColor,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(color: Colors.grey[600], fontSize: 14)),
        Flexible(
          child: Text(
            value,
            textAlign: TextAlign.end,
            style: TextStyle(
              color: valueColor ?? Colors.black87,
              fontWeight: isBold ? FontWeight.bold : FontWeight.w600,
              fontSize: 14,
            ),
          ),
        ),
      ],
    );
  }
}

// ── Animated success graphic ───────────────────────────────────────────────────

class _AnimatedSuccessGraphic extends StatefulWidget {
  @override
  State<_AnimatedSuccessGraphic> createState() =>
      _AnimatedSuccessGraphicState();
}

class _AnimatedSuccessGraphicState extends State<_AnimatedSuccessGraphic>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    )..forward();
    _scale = CurvedAnimation(parent: _controller, curve: Curves.elasticOut);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _scale,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Container(
            height: 180,
            width: 180,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFFF47C20).withOpacity(0.10),
            ),
          ),
          Container(
            width: 130,
            height: 130,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: const Color(0xFF10B981).withOpacity(0.12),
            ),
            child: const Icon(
              Icons.check_circle_rounded,
              color: Color(0xFF10B981),
              size: 80,
            ),
          ),
        ],
      ),
    );
  }
}
