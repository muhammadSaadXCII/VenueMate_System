import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../Models/booking_model.dart';
import '../Services/booking_service.dart';

class ViewReceiptScreen extends StatelessWidget {
  final String bookingId;

  const ViewReceiptScreen({super.key, required this.bookingId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF5F5F5),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text(
          'View Receipt',
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
        centerTitle: true,
      ),
      body: StreamBuilder<BookingModel?>(
        stream: BookingService.streamBookingById(bookingId),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(color: Color(0xFFF97316)),
            );
          }

          if (!snapshot.hasData || snapshot.data == null) {
            return Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    Icons.receipt_long_outlined,
                    size: 60,
                    color: Colors.grey[400],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    'Receipt not found.',
                    style: TextStyle(color: Colors.grey[500], fontSize: 14),
                  ),
                ],
              ),
            );
          }

          return _ReceiptContent(booking: snapshot.data!);
        },
      ),
    );
  }
}

class _ReceiptContent extends StatefulWidget {
  final BookingModel booking;

  const _ReceiptContent({required this.booking});

  @override
  State<_ReceiptContent> createState() => _ReceiptContentState();
}

class _ReceiptContentState extends State<_ReceiptContent> {
  final GlobalKey _receiptKey = GlobalKey();
  bool _isDownloading = false;

  // ── Download receipt as PNG and share ─────────────────────────────────────
  Future<void> _downloadReceipt() async {
    setState(() => _isDownloading = true);
    try {
      // Capture the widget as image
      final boundary =
          _receiptKey.currentContext?.findRenderObject()
              as RenderRepaintBoundary?;
      if (boundary == null) return;

      final image = await boundary.toImage(pixelRatio: 3.0);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData == null) return;

      // Save to temp directory
      final dir = await getTemporaryDirectory();
      final file = File('${dir.path}/receipt_${widget.booking.invoiceId}.png');
      await file.writeAsBytes(byteData.buffer.asUint8List());

      // Share the file (save to gallery or share via apps)
      await Share.shareXFiles(
        [XFile(file.path)],
        subject: 'VenueMate Receipt ${widget.booking.invoiceId}',
        text: 'My booking receipt for ${widget.booking.eventName}',
      );
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Failed to download receipt. Please try again.'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _isDownloading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final booking = widget.booking;
    return SafeArea(
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              child: Column(
                children: [
                  // ── Capturable receipt card ────────────────────────────
                  RepaintBoundary(
                    key: _receiptKey,
                    child: Container(
                      width: double.infinity,
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFFDF6),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.05),
                            blurRadius: 20,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: Column(
                        children: [
                          // ── Header ─────────────────────────────────────
                          Container(
                            padding: const EdgeInsets.all(16),
                            decoration: const BoxDecoration(
                              color: Color(0xFFCACACA),
                              borderRadius: BorderRadius.vertical(
                                top: Radius.circular(20),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Logo area
                                Container(
                                  padding: const EdgeInsets.symmetric(
                                    horizontal: 8,
                                    vertical: 6,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Text(
                                    'VenueMate',
                                    style: TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                      color: Color(0xFFF47C20),
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 16),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Container(
                                      width: 80,
                                      height: 80,
                                      decoration: BoxDecoration(
                                        color:
                                            booking.isConfirmed
                                                ? const Color(
                                                  0xFF10B981,
                                                ).withOpacity(0.15)
                                                : const Color(0xFFFEF3C7),
                                        shape: BoxShape.circle,
                                      ),
                                      child: Icon(
                                        booking.isConfirmed
                                            ? Icons.check_circle_rounded
                                            : Icons.hourglass_top_rounded,
                                        color:
                                            booking.isConfirmed
                                                ? const Color(0xFF10B981)
                                                : const Color(0xFFD97706),
                                        size: 50,
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 12),
                                Center(
                                  child: Text(
                                    booking.isConfirmed
                                        ? 'Booking Confirmed'
                                        : 'Booking Pending',
                                    style: TextStyle(
                                      color:
                                          booking.isConfirmed
                                              ? const Color(0xFF059669)
                                              : const Color(0xFFD97706),
                                      fontSize: 20,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),

                          // ── Receipt body ───────────────────────────────
                          Padding(
                            padding: const EdgeInsets.all(24.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                // Invoice ID & status
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'Invoice ID',
                                          style: TextStyle(
                                            color: Colors.grey,
                                            fontSize: 12,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          booking.invoiceId,
                                          style: const TextStyle(
                                            fontWeight: FontWeight.bold,
                                            fontSize: 16,
                                          ),
                                        ),
                                      ],
                                    ),
                                    Container(
                                      padding: const EdgeInsets.symmetric(
                                        horizontal: 12,
                                        vertical: 6,
                                      ),
                                      decoration: BoxDecoration(
                                        color:
                                            booking.isConfirmed
                                                ? Colors.green.withOpacity(0.1)
                                                : Colors.orange.withOpacity(
                                                  0.1,
                                                ),
                                        borderRadius: BorderRadius.circular(20),
                                        border: Border.all(
                                          color:
                                              booking.isConfirmed
                                                  ? Colors.green.withOpacity(
                                                    0.3,
                                                  )
                                                  : Colors.orange.withOpacity(
                                                    0.3,
                                                  ),
                                        ),
                                      ),
                                      child: Text(
                                        booking.isConfirmed
                                            ? 'PAID (Advance)'
                                            : 'PENDING',
                                        style: TextStyle(
                                          color:
                                              booking.isConfirmed
                                                  ? Colors.green
                                                  : Colors.orange[800],
                                          fontSize: 12,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 6),
                                Text(
                                  booking.hallName,
                                  style: const TextStyle(
                                    color: Colors.black54,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),

                                const SizedBox(height: 24),

                                // ── Billed To ─────────────────────────────
                                const Text(
                                  'Billed To',
                                  style: TextStyle(
                                    color: Colors.grey,
                                    fontSize: 13,
                                  ),
                                ),
                                const SizedBox(height: 12),
                                _infoRow(
                                  'Name',
                                  booking.customerName,
                                  'Phone',
                                  booking.customerPhone,
                                ),
                                const SizedBox(height: 10),
                                _infoRow(
                                  'CNIC',
                                  booking.customerCnic,
                                  null,
                                  null,
                                ),
                                const SizedBox(height: 10),
                                _infoRow(
                                  'Event',
                                  booking.eventName,
                                  'Guests',
                                  '${booking.guestCount}',
                                ),
                                const SizedBox(height: 10),
                                _infoRow(
                                  'Date',
                                  booking.eventDateLabel,
                                  null,
                                  null,
                                ),

                                const SizedBox(height: 24),
                                const _DashedDivider(height: 2),
                                const SizedBox(height: 24),

                                // ── Items Summary ──────────────────────────
                                const Text(
                                  'Items Summary',
                                  style: TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 15,
                                  ),
                                ),
                                const SizedBox(height: 16),

                                _summaryRow(
                                  'Hall Rent',
                                  'Rs. ${booking.hallRent.toStringAsFixed(0)}',
                                ),

                                if (booking.selectedMenuItems.isNotEmpty)
                                  _summaryRow(
                                    'Menu (${booking.selectedMenuItems.length} item${booking.selectedMenuItems.length > 1 ? 's' : ''})',
                                    'Rs. ${booking.menuSubtotal.toStringAsFixed(0)}',
                                  ),

                                if (booking.selectedServices.isNotEmpty)
                                  _summaryRow(
                                    'Services (${booking.selectedServices.length})',
                                    'Rs. ${booking.servicesSubtotal.toStringAsFixed(0)}',
                                  ),

                                const SizedBox(height: 12),
                                const _DashedDivider(height: 2),
                                const SizedBox(height: 12),

                                _summaryRow(
                                  'Grand Total',
                                  'Rs. ${booking.grandTotal.toStringAsFixed(0)}',
                                  isBold: true,
                                ),
                                _summaryRow(
                                  '25% Advance Payment',
                                  'Rs. ${booking.advancePayment.toStringAsFixed(0)}',
                                  isHighlight: true,
                                ),

                                const SizedBox(height: 12),
                                const _DashedDivider(height: 2),
                                const SizedBox(height: 16),

                                // Remaining balance
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    const Text(
                                      'Remaining Payment',
                                      style: TextStyle(
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    Text(
                                      'Rs. ${booking.remainingPayment.toStringAsFixed(0)}',
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        color: Colors.red[700],
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 16),

                                // Rejection reason (if any)
                                if (booking.isRejected &&
                                    booking.rejectionReason.isNotEmpty) ...[
                                  const _DashedDivider(height: 2),
                                  const SizedBox(height: 16),
                                  Container(
                                    padding: const EdgeInsets.all(12),
                                    decoration: BoxDecoration(
                                      color: Colors.red[50],
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(
                                        color: Colors.red[200]!,
                                      ),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const Text(
                                          'Payment Rejected:',
                                          style: TextStyle(
                                            color: Colors.red,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 13,
                                          ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          booking.rejectionReason,
                                          style: TextStyle(
                                            color: Colors.red[700],
                                            fontSize: 12,
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 100),
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
        child: SizedBox(
          width: double.infinity,
          height: 54,
          child: ElevatedButton.icon(
            onPressed: _isDownloading ? null : _downloadReceipt,
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFF47C20),
              disabledBackgroundColor: const Color(0xFFF47C20).withOpacity(0.6),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              elevation: 0,
            ),
            icon:
                _isDownloading
                    ? const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        color: Colors.white,
                        strokeWidth: 2.5,
                      ),
                    )
                    : const Icon(
                      Icons.download_rounded,
                      color: Colors.white,
                      size: 24,
                    ),
            label: Text(
              _isDownloading ? 'Preparing...' : 'Download Receipt',
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── Helper Widgets ─────────────────────────────────────────────────────────

  Widget _infoRow(
    String label1,
    String value1,
    String? label2,
    String? value2,
  ) {
    return Row(
      children: [
        Expanded(
          flex: 3,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label1,
                style: const TextStyle(color: Colors.grey, fontSize: 11),
              ),
              const SizedBox(height: 2),
              Text(
                value1,
                style: const TextStyle(
                  fontWeight: FontWeight.w600,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
        if (label2 != null && value2 != null)
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(
                  label2,
                  style: const TextStyle(color: Colors.grey, fontSize: 11),
                ),
                const SizedBox(height: 2),
                Text(
                  value2,
                  style: const TextStyle(
                    fontWeight: FontWeight.w600,
                    fontSize: 13,
                  ),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _summaryRow(
    String title,
    String amount, {
    bool isBold = false,
    bool isHighlight = false,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: TextStyle(
              fontSize: isBold ? 15 : 13,
              fontWeight: isBold ? FontWeight.bold : FontWeight.w500,
              color: Colors.black87,
            ),
          ),
          Text(
            amount,
            style: TextStyle(
              fontSize: isBold ? 15 : 13,
              fontWeight: isBold ? FontWeight.bold : FontWeight.w500,
              color: isHighlight ? Colors.green[700] : Colors.black,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Dashed Divider ─────────────────────────────────────────────────────────────

class _DashedDivider extends StatelessWidget {
  final double height;
  final Color color;

  const _DashedDivider({this.height = 1, this.color = Colors.grey});

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (_, constraints) {
        final boxWidth = constraints.constrainWidth();
        const dashWidth = 5.0;
        final dashCount = (boxWidth / (2 * dashWidth)).floor();
        return Flex(
          direction: Axis.horizontal,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: List.generate(dashCount, (_) {
            return SizedBox(
              width: dashWidth,
              height: height,
              child: DecoratedBox(
                decoration: BoxDecoration(color: color.withOpacity(0.3)),
              ),
            );
          }),
        );
      },
    );
  }
}
