import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../Models/booking_model.dart';
import '../Models/menu_item_model.dart';
import '../Models/service_item_model.dart';
import 'storage_service.dart';

/// Handles all Firestore + Storage operations for the `bookings` collection.
///
/// Firestore path:  bookings/{bookingId}
/// Storage path:    payments/{bookingId}/receipt_{uuid}.jpg
class BookingService {
  static final _db = FirebaseFirestore.instance;
  static final _bookings = _db.collection('bookings');
  static const _uuid = Uuid();

  // ════════════════════════════════════════════════════════════════════════════
  //  CREATE — called from PaymentScreen after customer uploads receipt
  // ════════════════════════════════════════════════════════════════════════════

  /// Creates a new booking document in Firestore.
  ///
  /// [selectedMenuItems] → items chosen in CustomizeEventScreen
  /// [selectedServices]  → services chosen in CustomizeEventScreen
  /// [receiptFile]       → image captured in PaymentScreen
  ///
  /// Returns the new [bookingId] on success, or null on error.
  static Future<String?> createBooking({
    // ── IDs ─────────────────────────────────────────────────────────────────
    required String hallId,
    required String hallName,
    required String customerId,
    // ── Step 1: Basic Details ────────────────────────────────────────────────
    required String customerName,
    required String customerPhone,
    required String customerCnic,
    required String customerEmail,
    // ── Step 2: Event Details ────────────────────────────────────────────────
    required String eventName,
    required int guestCount,
    required String timeSlot,
    required DateTime eventDate,
    // ── Step 3: Customize Event ──────────────────────────────────────────────
    required List<MenuItemModel> selectedMenuItems,
    required List<ServiceItemModel> selectedServices,
    // ── Step 4: Payment ──────────────────────────────────────────────────────
    required double hallRent,
    required File receiptFile,
  }) async {
    try {
      final String bookingId = _uuid.v4();

      // 1. Upload payment receipt to Firebase Storage
      final String? receiptUrl = await StorageService.uploadPaymentReceipt(
        bookingId: bookingId,
        receiptFile: receiptFile,
      );
      if (receiptUrl == null) return null;

      // 2. Compute totals
      final double menuSubtotal = selectedMenuItems.fold(
        0.0,
        (sum, item) => sum + item.price,
      );
      final double servicesSubtotal = selectedServices.fold(
        0.0,
        (sum, svc) => sum + svc.price,
      );
      final double grandTotal = hallRent + menuSubtotal + servicesSubtotal;
      final double advancePayment = grandTotal * 0.25;

      // 3. Build BookingModel
      final BookingModel booking = BookingModel(
        bookingId: bookingId,
        hallId: hallId,
        hallName: hallName,
        customerId: customerId,
        customerName: customerName,
        customerPhone: customerPhone,
        customerCnic: customerCnic,
        customerEmail: customerEmail,
        eventName: eventName,
        guestCount: guestCount,
        timeSlot: timeSlot,
        eventDate: eventDate,
        selectedMenuItems:
            selectedMenuItems
                .map(
                  (m) => BookingMenuItemModel(
                    itemId: m.itemId,
                    name: m.name,
                    price: m.price,
                    priceUnit: m.priceUnit,
                  ),
                )
                .toList(),
        selectedServices:
            selectedServices
                .map(
                  (s) => BookingServiceModel(
                    serviceId: s.serviceId,
                    name: s.name,
                    price: s.price,
                  ),
                )
                .toList(),
        hallRent: hallRent,
        menuSubtotal: menuSubtotal,
        servicesSubtotal: servicesSubtotal,
        grandTotal: grandTotal,
        advancePayment: advancePayment,
        receiptImageUrl: receiptUrl,
        status: 'pending', // awaiting hall admin verification
        createdAt: DateTime.now(),
      );

      // 4. Save to Firestore
      await _bookings.doc(bookingId).set(booking.toMap());

      return bookingId; // success
    } catch (_) {
      return null;
    }
  }

  // ════════════════════════════════════════════════════════════════════════════
  //  READ — Customer side
  // ════════════════════════════════════════════════════════════════════════════

  /// Stream all bookings for a specific customer (real-time).
  /// Used in AllEventsScreen and ProfileScreen.
  static Stream<List<BookingModel>> streamCustomerBookings(String customerId) {
    return _bookings
        .where('customerId', isEqualTo: customerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => BookingModel.fromDoc(d)).toList());
  }

  /// One-time fetch of a single booking by ID.
  /// Used in ViewReceiptScreen and CongratulationsScreen.
  static Future<BookingModel?> getBookingById(String bookingId) async {
    try {
      final doc = await _bookings.doc(bookingId).get();
      if (!doc.exists) return null;
      return BookingModel.fromDoc(doc);
    } catch (_) {
      return null;
    }
  }

  /// Stream a single booking in real-time.
  static Stream<BookingModel?> streamBookingById(String bookingId) {
    return _bookings.doc(bookingId).snapshots().map((doc) {
      if (!doc.exists) return null;
      return BookingModel.fromDoc(doc);
    });
  }

  // ════════════════════════════════════════════════════════════════════════════
  //  READ — Hall Admin side
  // ════════════════════════════════════════════════════════════════════════════

  /// Stream all bookings for a specific hall (real-time).
  /// Used in HallAdminBookingsScreen.
  static Stream<List<BookingModel>> streamHallBookings(String hallId) {
    return _bookings
        .where('hallId', isEqualTo: hallId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => BookingModel.fromDoc(d)).toList());
  }

  /// Stream only pending bookings for a hall (receipt not yet verified).
  static Stream<List<BookingModel>> streamPendingBookings(String hallId) {
    return _bookings
        .where('hallId', isEqualTo: hallId)
        .where('status', isEqualTo: 'pending')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => BookingModel.fromDoc(d)).toList());
  }

  /// Stream confirmed bookings for a hall.
  static Stream<List<BookingModel>> streamConfirmedBookings(String hallId) {
    return _bookings
        .where('hallId', isEqualTo: hallId)
        .where('status', isEqualTo: 'confirmed')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => BookingModel.fromDoc(d)).toList());
  }

  // ════════════════════════════════════════════════════════════════════════════
  //  UPDATE — Hall Admin: Verify or Reject Receipt
  // ════════════════════════════════════════════════════════════════════════════

  /// Hall admin APPROVES the payment receipt → booking is confirmed.
  /// Returns null on success, error string on failure.
  static Future<String?> confirmBooking(String bookingId) async {
    try {
      await _bookings.doc(bookingId).update({
        'status': 'confirmed',
        'rejectionReason': '',
      });
      return null;
    } catch (_) {
      return 'Failed to confirm booking.';
    }
  }

  /// Hall admin REJECTS the payment receipt → booking stays unconfirmed.
  /// [reason] is shown to the customer.
  /// Returns null on success, error string on failure.
  static Future<String?> rejectBookingPayment({
    required String bookingId,
    required String reason,
  }) async {
    try {
      await _bookings.doc(bookingId).update({
        'status': 'rejected',
        'rejectionReason': reason,
      });
      return null;
    } catch (_) {
      return 'Failed to reject booking.';
    }
  }

  // ════════════════════════════════════════════════════════════════════════════
  //  UPDATE — Customer: Cancel Booking
  // ════════════════════════════════════════════════════════════════════════════

  /// Customer cancels their own booking.
  /// Only allowed when status is 'pending' or 'confirmed'.
  /// Returns null on success, error string on failure.
  static Future<String?> cancelBooking(String bookingId) async {
    try {
      await _bookings.doc(bookingId).update({'status': 'cancelled'});
      return null;
    } catch (_) {
      return 'Failed to cancel booking.';
    }
  }
}
