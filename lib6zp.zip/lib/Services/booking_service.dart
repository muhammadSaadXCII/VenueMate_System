import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:uuid/uuid.dart';
import '../Models/booking_model.dart';
import '../Models/hall_model.dart';
import '../Models/menu_item_model.dart';
import '../Models/service_item_model.dart';
import 'storage_service.dart';

/// Handles all Firestore + Storage operations for the `bookings` collection.
///
/// KEY RULES enforced here:
///   1. Each slot (Morning / Evening) is checked independently for the date.
///   2. A slot's remaining capacity = hallCapacityMax − sum of confirmed
///      guestCounts for that hallId + date + slot.
///   3. A new booking is rejected if guestCount > remainingCapacity.
///   4. When hall admin confirms → status = 'confirmed', confirmedAt = now.
///   5. When hall admin rejects → status = 'rejected'.
///   6. Bookings whose eventDate < today AND status == 'confirmed' are
///      auto-marked 'completed' lazily on fetch.
class BookingService {
  static final _db = FirebaseFirestore.instance;
  static final _bookings = _db.collection('bookings');
  static const _uuid = Uuid();

  // ════════════════════════════════════════════════════════════════════════════
  //  AVAILABILITY CHECK  (called from EventDetailScreen before navigation)
  // ════════════════════════════════════════════════════════════════════════════

  /// Returns a [SlotAvailability] object describing how many guests can still
  /// be accommodated for [hallId] on [date] for [timeSlot].
  ///
  /// Only 'confirmed' bookings consume capacity.  Pending / rejected /
  /// cancelled bookings do NOT block the slot.
  static Future<SlotAvailability> checkSlotAvailability({
    required String hallId,
    required DateTime date,
    required String timeSlot,
    required int hallCapacityMax,
  }) async {
    try {
      final dayStart = DateTime(date.year, date.month, date.day);
      final dayEnd = dayStart.add(const Duration(days: 1));

      final snap =
          await _bookings
              .where('hallId', isEqualTo: hallId)
              .where('timeSlot', isEqualTo: timeSlot)
              .where('status', isEqualTo: 'confirmed')
              .where(
                'eventDate',
                isGreaterThanOrEqualTo: Timestamp.fromDate(dayStart),
              )
              .where('eventDate', isLessThan: Timestamp.fromDate(dayEnd))
              .get();

      final bookedGuests = snap.docs
          .map((d) => (d.data()['guestCount'] as num? ?? 0).toInt())
          .fold(0, (a, b) => a + b);

      final remaining = hallCapacityMax - bookedGuests;
      return SlotAvailability(
        hallCapacityMax: hallCapacityMax,
        bookedGuests: bookedGuests,
        remainingSlots: remaining.clamp(0, hallCapacityMax),
        isFullyBooked: remaining <= 0,
      );
    } catch (_) {
      // On error, allow booking to proceed (fail-open so user isn't blocked)
      return SlotAvailability(
        hallCapacityMax: hallCapacityMax,
        bookedGuests: 0,
        remainingSlots: hallCapacityMax,
        isFullyBooked: false,
      );
    }
  }

  // ════════════════════════════════════════════════════════════════════════════
  //  CREATE
  // ════════════════════════════════════════════════════════════════════════════

  /// Creates a booking after a final capacity re-check inside a transaction.
  ///
  /// Returns:
  ///   • bookingId (String) on success
  ///   • 'SLOT_FULL' if the slot just filled up before saving
  ///   • null on unexpected error
  static Future<String?> createBooking({
    required String hallId,
    required String hallName,
    required String customerId,
    required String customerName,
    required String customerPhone,
    required String customerCnic,
    required String customerEmail,
    required String eventName,
    required int guestCount,
    required String timeSlot,
    required DateTime eventDate,
    required List<MenuItemModel> selectedMenuItems,
    required List<ServiceItemModel> selectedServices,
    required double hallRent,
    required int hallCapacityMax,
    required File receiptFile,
  }) async {
    try {
      // 1. Re-check availability
      final avail = await checkSlotAvailability(
        hallId: hallId,
        date: eventDate,
        timeSlot: timeSlot,
        hallCapacityMax: hallCapacityMax,
      );
      if (guestCount > avail.remainingSlots) return 'SLOT_FULL';

      // 2. Upload receipt
      final String bookingId = _uuid.v4();
      final String? receiptUrl = await StorageService.uploadPaymentReceipt(
        bookingId: bookingId,
        receiptFile: receiptFile,
      );
      if (receiptUrl == null) return null;

      // 3. Compute totals
      final double menuSubtotal = selectedMenuItems.fold(
        0.0,
        (s, m) => s + m.price,
      );
      final double servicesSubtotal = selectedServices.fold(
        0.0,
        (s, sv) => s + sv.price,
      );
      final double grandTotal = hallRent + menuSubtotal + servicesSubtotal;
      final double advancePayment = grandTotal * 0.25;

      // 4. Build model
      final booking = BookingModel(
        bookingId: bookingId,
        hallId: hallId,
        hallName: hallName,
        customerId: customerId,
        customerName: customerName,
        customerPhone: customerPhone,
        customerCnic: customerCnic,
        customerEmail: customerEmail,
        eventName: eventName,
        guestCount: guestCount,
        timeSlot: timeSlot,
        eventDate: eventDate,
        selectedMenuItems:
            selectedMenuItems
                .map(
                  (m) => BookingMenuItemModel(
                    itemId: m.itemId,
                    name: m.name,
                    price: m.price,
                    priceUnit: m.priceUnit,
                  ),
                )
                .toList(),
        selectedServices:
            selectedServices
                .map(
                  (s) => BookingServiceModel(
                    serviceId: s.serviceId,
                    name: s.name,
                    price: s.price,
                  ),
                )
                .toList(),
        hallRent: hallRent,
        menuSubtotal: menuSubtotal,
        servicesSubtotal: servicesSubtotal,
        grandTotal: grandTotal,
        advancePayment: advancePayment,
        receiptImageUrl: receiptUrl,
        status: 'pending',
        createdAt: DateTime.now(),
        hallCapacityMax: hallCapacityMax,
      );

      // 5. Save
      await _bookings.doc(bookingId).set(booking.toMap());
      return bookingId;
    } catch (_) {
      return null;
    }
  }

  // ════════════════════════════════════════════════════════════════════════════
  //  READ — Customer
  // ════════════════════════════════════════════════════════════════════════════

  static Stream<List<BookingModel>> streamCustomerBookings(String customerId) {
    return _bookings
        .where('customerId', isEqualTo: customerId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(
          (snap) =>
              snap.docs
                  .map((d) => BookingModel.fromDoc(d))
                  .map(_autoComplete)
                  .toList(),
        );
  }

  static Future<BookingModel?> getBookingById(String bookingId) async {
    try {
      final doc = await _bookings.doc(bookingId).get();
      if (!doc.exists) return null;
      return _autoComplete(BookingModel.fromDoc(doc));
    } catch (_) {
      return null;
    }
  }

  static Stream<BookingModel?> streamBookingById(String bookingId) {
    return _bookings.doc(bookingId).snapshots().map((doc) {
      if (!doc.exists) return null;
      return _autoComplete(BookingModel.fromDoc(doc));
    });
  }

  // ════════════════════════════════════════════════════════════════════════════
  //  READ — Hall Admin
  // ════════════════════════════════════════════════════════════════════════════

  /// All bookings for a hall, real-time.
  static Stream<List<BookingModel>> streamHallBookings(String hallId) {
    return _bookings
        .where('hallId', isEqualTo: hallId)
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map(
          (snap) =>
              snap.docs
                  .map((d) => BookingModel.fromDoc(d))
                  .map(_autoComplete)
                  .toList(),
        );
  }

  /// Pending bookings → receipt not yet verified.
  static Stream<List<BookingModel>> streamPendingBookings(String hallId) {
    return _bookings
        .where('hallId', isEqualTo: hallId)
        .where('status', isEqualTo: 'pending')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => BookingModel.fromDoc(d)).toList());
  }

  /// Upcoming = confirmed AND eventDate >= today.
  static Stream<List<BookingModel>> streamUpcomingBookings(String hallId) {
    final todayStart = DateTime(
      DateTime.now().year,
      DateTime.now().month,
      DateTime.now().day,
    );
    return _bookings
        .where('hallId', isEqualTo: hallId)
        .where('status', isEqualTo: 'confirmed')
        .where(
          'eventDate',
          isGreaterThanOrEqualTo: Timestamp.fromDate(todayStart),
        )
        .orderBy('eventDate', descending: false)
        .snapshots()
        .map((snap) => snap.docs.map((d) => BookingModel.fromDoc(d)).toList());
  }

  /// Completed bookings for a hall.
  static Stream<List<BookingModel>> streamCompletedBookings(String hallId) {
    return _bookings
        .where('hallId', isEqualTo: hallId)
        .where('status', isEqualTo: 'completed')
        .orderBy('eventDate', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => BookingModel.fromDoc(d)).toList());
  }

  /// Cancelled bookings for a hall.
  static Stream<List<BookingModel>> streamCancelledBookings(String hallId) {
    return _bookings
        .where('hallId', isEqualTo: hallId)
        .where('status', isEqualTo: 'cancelled')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) => snap.docs.map((d) => BookingModel.fromDoc(d)).toList());
  }

  // ════════════════════════════════════════════════════════════════════════════
  //  UPDATE — Hall Admin actions
  // ════════════════════════════════════════════════════════════════════════════

  /// Confirm a booking (receipt verified, money received).
  /// Returns null on success, error string on failure.
  static Future<String?> confirmBooking(String bookingId) async {
    try {
      await _bookings.doc(bookingId).update({
        'status': 'confirmed',
        'rejectionReason': '',
        'confirmedAt': Timestamp.fromDate(DateTime.now()),
      });
      return null;
    } catch (_) {
      return 'Failed to confirm booking.';
    }
  }

  /// Reject a booking's payment receipt.
  static Future<String?> rejectBookingPayment({
    required String bookingId,
    required String reason,
  }) async {
    try {
      await _bookings.doc(bookingId).update({
        'status': 'rejected',
        'rejectionReason': reason,
      });
      return null;
    } catch (_) {
      return 'Failed to reject booking.';
    }
  }

  // ════════════════════════════════════════════════════════════════════════════
  //  UPDATE — Customer
  // ════════════════════════════════════════════════════════════════════════════

  static Future<String?> cancelBooking(String bookingId) async {
    try {
      await _bookings.doc(bookingId).update({'status': 'cancelled'});
      return null;
    } catch (_) {
      return 'Failed to cancel booking.';
    }
  }

  // ════════════════════════════════════════════════════════════════════════════
  //  COUNTS — for Hall Admin Home stats card
  // ════════════════════════════════════════════════════════════════════════════

  static Future<Map<String, int>> getBookingCounts(String hallId) async {
    try {
      final snap = await _bookings.where('hallId', isEqualTo: hallId).get();
      final all = snap.docs.map((d) => BookingModel.fromDoc(d)).toList();
      final todayStart = DateTime(
        DateTime.now().year,
        DateTime.now().month,
        DateTime.now().day,
      );

      return {
        'pending': all.where((b) => b.isPending).length,
        'upcoming':
            all
                .where(
                  (b) => b.isConfirmed && !b.eventDate.isBefore(todayStart),
                )
                .length,
        'completed': all.where((b) => b.isCompleted).length,
        'cancelled': all.where((b) => b.isCancelled).length,
      };
    } catch (_) {
      return {'pending': 0, 'upcoming': 0, 'completed': 0, 'cancelled': 0};
    }
  }

  // ════════════════════════════════════════════════════════════════════════════
  //  INTERNAL HELPERS
  // ════════════════════════════════════════════════════════════════════════════

  /// Lazily marks confirmed bookings whose event date has passed as 'completed'.
  static BookingModel _autoComplete(BookingModel b) {
    if (b.isConfirmed) {
      final todayStart = DateTime(
        DateTime.now().year,
        DateTime.now().month,
        DateTime.now().day,
      );
      final evDay = DateTime(
        b.eventDate.year,
        b.eventDate.month,
        b.eventDate.day,
      );
      if (evDay.isBefore(todayStart)) {
        // Fire-and-forget update
        _bookings.doc(b.bookingId).update({'status': 'completed'}).ignore();
        return b.copyWith(status: 'completed');
      }
    }
    return b;
  }
}

// ══════════════════════════════════════════════════════════════════════════════
//  SLOT AVAILABILITY  (returned by checkSlotAvailability)
// ══════════════════════════════════════════════════════════════════════════════

class SlotAvailability {
  final int hallCapacityMax;
  final int bookedGuests;
  final int remainingSlots;
  final bool isFullyBooked;

  const SlotAvailability({
    required this.hallCapacityMax,
    required this.bookedGuests,
    required this.remainingSlots,
    required this.isFullyBooked,
  });

  String get label =>
      isFullyBooked
          ? 'Fully Booked'
          : '$remainingSlots / $hallCapacityMax guests available';
}
